import datetime
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Color, PatternFill, Font, Border
from openpyxl.styles import colors
from openpyxl.cell import Cell

def solveIt(data, peoples, files):
    string_imc = [ 'Desnutrição grau V', 'Desnutrição grau IV', 'Desnutrição grau III', 'Desnutrição grau II',
    'Desnutrição grau I', 'Normal', 'Pré-obesidade', 'Obesidade grau I', 'Obesidade grau II', 'Obesidade grau III' ]
    today = datetime.datetime.today()
    peoples['A'][0].value = 'Identificação numérica'
    peoples['B'][0].value = 'Nome'
    peoples['C'][0].value = 'Sobrenome'
    peoples['D'][0].value = 'RG'
    peoples['E'][0].value = 'Sexo'
    peoples['F'][0].value = 'Data de nascimento'
    peoples['G'][0].value = 'Idade'
    peoples['H'][0].value = 'Peso (KG)'
    peoples['I'][0].value = 'Altura (m)'
    peoples['J'][0].value = 'IMC'
    peoples['K'][0].value = 'Estado nutricional'
    r_imc = []
    i = 1
    for row in data[1:]:
        w = int(row[12])
        h = round(float(int(row[13]) / 100), 2)
        this_img = round(float(w / (h * h)), 2)
        r_imc.append(this_img)
        y,m,d = [int(x) for x in row[9].split('-')]
        imc_str = 0 if this_img < 10 else (
            1 if 10 <= this_img <= 12.9 else (
                2 if 13 <= this_img <= 15.9 else (
                    3 if 16 <= this_img <= 16.9 else (
                        4 if 17 <= this_img <= 18.4 else (
                            5 if 18.5 <= this_img <= 24.9 else (
                                6 if 30 <= this_img <= 29.9 else (
                                    7 if 30 <= this_img <= 34.5 else (
                                        8 if 35 <= this_img <= 39.9 else 9
                                    )
                                )
                            )
                        )
                    )
                )
            )
        )
        peoples.append((
            row[0], 
            row[4] + ' ' + row[5],
            row[6] + ' ' + row[7],
            row[8],
            row[10],
            row[9],
            today.year - y - ((today.month, today.day) < (m, d)),
            w,
            h,
            this_img,
            string_imc[imc_str]
        ))
        i += 1
        c = peoples.cell(column=11, row=i)
        if imc_str != 5:
            c.font = Font(bold=True, name='Arial', color='FFF00000')
        else:
            c.font = Font(bold=True, name='Arial', color='228B22')
    peoples.append((
        '',
        'MÉDIA',
        '',
        '',
        '',
        '',
        '=MEDIAN(G1:G43)',
        '=MEDIAN(H1:H43)',
        '=MEDIAN(I1:I43)',
        '=MEDIAN(J1:J43)',
        ''
    ))
    peoples.append((
        '',
        'DESVIO PADRÃO',
        '',
        '',
        '',
        '',
        '=STDEV(G1:G43)',
        '=STDEV(H1:H43)',
        '=STDEV(I1:I43)',
        '=STDEV(J1:J43)',
        ''
    ))
    for cell in peoples[1]:
        cell.fill = PatternFill(start_color="aabedd", end_color="aabedd", fill_type = "solid")
        cell.font = Font(bold=True, name='Arial', color='FFFFFFFF')
    
    for cell in peoples[44]:
        cell.fill = PatternFill(start_color="aabedd", end_color="aabedd", fill_type = "solid")
        cell.font = Font(bold=True, name='Arial', color='FFFFFFFF')
    for cell in peoples[45]:
        cell.fill = PatternFill(start_color="aabedd", end_color="aabedd", fill_type = "solid")
        cell.font = Font(bold=True, name='Arial', color='FFFFFFFF')

# filename = input()
wb = load_workbook('DadosSIG.xlsx')
ws = wb.get_sheet_by_name('Hoja1')
file_1 = Workbook()
file_2 = Workbook()
all_rows = []
for row in ws:
    current_row = []
    for cell in row:
        current_row.append(cell.value)
    all_rows.append(current_row)

solveIt(all_rows,file_1.active, file_2.active)
file_1.save('Pessoas.xlsx')
file_2.save('Ficha.xlsx')